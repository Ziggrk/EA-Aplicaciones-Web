# Examen Parcial Aplicaciones web

## Dato del Alumno

Nombres: William Martin

Apellidos: Riega Ocharan 

Codigo: U202112272

Seccion: SW53

## Aclaraciones

Se ha realizado la validación de idioma en ingles y español. 
De igual forma cualquier ruta no especificada derivara al 
componente `page-not-found`. La ruta raiz redireccionara de igual
manera al componente `home`. 

## Instalaciones realizadas

```sh
npm install
```
```sh
npm install primevue
```
```sh
npm install primeicons
```
```sh
npm install vue-router@4
```
```sh
npm install vue-i18n@9
```
```sh
npm install json-server
```
